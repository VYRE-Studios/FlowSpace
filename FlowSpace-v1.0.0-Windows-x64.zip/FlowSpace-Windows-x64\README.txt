# FlowSpace v1.0.0

## Quick Start (One-Click Setup)

1. Extract this archive to C:\FlowSpace
2. Right-click ONE-CLICK-SETUP.ps1 and select "Run with PowerShell"
3. Wait for setup to complete (takes ~2-3 minutes)
4. Double-click the FlowSpace shortcut on your desktop
5. That's it! FlowSpace handles everything automatically.

## Manual Installation

If you prefer manual setup:

1. Extract this archive to a folder (e.g., C:\FlowSpace)
2. Open PowerShell in the FlowSpace directory
3. Run: .\AUTO-SETUP.ps1
4. Follow the on-screen instructions

## Requirements

- Windows 10/11 (64-bit)
- Node.js 18+ (auto-installed if missing)
- Flutter SDK (auto-installed if missing)
- PostgreSQL (auto-configured if available, otherwise uses embedded SQLite)

## Features

- ✅ One-click setup - no manual configuration needed
- ✅ Automatic service management - backend runs in background
- ✅ Embedded database option - works without PostgreSQL
- ✅ Secure credential storage - encrypted in Windows Credential Manager
- ✅ Multi-user support - add team members seamlessly
- ✅ Real-time collaboration - messaging, projects, file sharing

## What Gets Installed

- FlowSpace desktop application
- Backend API services (auto-started)
- Database (PostgreSQL or embedded SQLite)
- Desktop shortcut for easy access

## Support

For issues and questions, please open an issue on GitHub:
https://github.com/RedWoodOG/FlowSpace/issues

## License

See LICENSE file in the repository.
